<?php get_header(); ?>

	<div class="py-20 px-1/10">
		<h1 class="text-2xl xs:text-3xl text-center">404: Page Not Found</h1>
	</div>

<?php get_footer(); ?>