<?php

add_action( 'after_setup_theme', 'custom_setup' );

if ( ! function_exists( 'custom_setup' ) ) {
	function custom_setup() {

		add_theme_support( 'title-tag' );

		register_nav_menus( array(
			'left' => __( 'Left Menu', 'default' ),
			'right' => __( 'Right Menu', 'default' ),
			'footer' => __( 'Footer Menu', 'default' ),
			'mobile' => __( 'Mobile Menu', 'default' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		/*
		 * Adding Thumbnail basic support
		 */
		add_theme_support( 'post-thumbnails' );

		/*
		 * Adding support for Widget edit icons in customizer
		 */
		add_theme_support( 'customize-selective-refresh-widgets' );

		/*
		 * Enable support for Post Formats.
		 * See http://codex.wordpress.org/Post_Formats
		 */
		add_theme_support( 'post-formats', array(
			'aside',
			'image',
			'video',
			'quote',
			'link',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Set up the WordPress Theme logo feature.
		add_theme_support( 'custom-logo' );

		// Add support for responsive embedded content.
		add_theme_support( 'responsive-embeds' );

		// add_theme_support( 'woocommerce' );
	}
}

